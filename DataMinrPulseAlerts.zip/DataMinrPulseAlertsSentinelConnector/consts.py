"""This file contains all constants."""
SOURCE_SEPARATOR = 'via '
BASE_URL = 'https://gateway.dataminr.com/'
ENDPOINTS = {
                "authentication": "auth/2/token",
                "get_lists": "account/2/get_lists",
                "get_alerts": "api/3/alerts",
                "get_related_alerts": "alerts/2/get_related"
            }
ALERT_VERSION = 14
LOGS_STARTS_WITH = "DataMinrPulseAlerts:"
DATETIME_FORMAT = "%Y-%m-%d %H:%M:%S"
