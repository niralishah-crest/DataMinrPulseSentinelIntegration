"""This file contains implementation of dataminr alert fetching."""
import requests
import inspect
import json
import os
from .logger import applogger
from .sentinel import AzureSentinel
from datetime import datetime
from .consts import (
    BASE_URL,
    ENDPOINTS,
    LOGS_STARTS_WITH,
    DATETIME_FORMAT,
    ALERT_VERSION,
    SOURCE_SEPARATOR,
)
from .dataminr_exception import DataMinrException
from .state_manager import StateManager

# fetch data from os environment
client_id = os.environ.get("ClientId")
client_secret = os.environ.get("ClientSecret")
alert_type = os.environ.get("AlertType")
lists_names = os.environ.get("ListsNames")
related_alerts = os.environ.get("RelatedAlerts")
alerts_table = os.environ.get("AlertsTableName")
connection_string = os.environ.get("AzureWebJobsStorage")


class DataMinr:
    """This class contains methods to authenticate with DataMinr and fetch alerts using API."""

    def __init__(self) -> None:
        """Initialize instance variable for class."""
        self.client_id = client_id
        self.client_secret = client_secret
        self.lists_ids = []
        self.base_url = BASE_URL
        self.auth_url = "{}{}".format(self.base_url, ENDPOINTS["authentication"])
        self.get_lists_path = ENDPOINTS["get_lists"]
        self.get_alerts_path = ENDPOINTS["get_alerts"]
        self.get_related_alerts_path = ENDPOINTS["get_related_alerts"]
        self.token_expiry_time = ""
        self.refresh_token = ""
        self.auth_headers = {"Content-Type": "application/x-www-form-urlencoded"}
        self.headers = {}
        self.logs_start_with = LOGS_STARTS_WITH
        self.datetime_format = DATETIME_FORMAT
        self.state = None
        self.alert_body = []
        self.alert_count = 0
        self.checkpoint_data = {}
        self.method_name = ""
        self.error_log = "{}(method={}) {}"

    def check_environment_var_exist(self):
        """To verify that all required environment variables are exist.

        Raises:
            DataMinrException: raise exception if any of the required environment variable is not set.
        """
        __method_name = inspect.currentframe().f_code.co_name
        env_var = [
            {"ClientId": client_id},
            {"ClientSecret": client_secret},
            {"AlertType": alert_type},
            {"RelatedAlerts": related_alerts},
            {"AlertsTableName": alerts_table},
        ]
        try:
            applogger.debug(
                "{}(method={}) Checking environment variables are exist or not.".format(
                    self.logs_start_with, __method_name
                )
            )
            for i in env_var:
                key, val = next(iter(i.items()))
                if val is None:
                    self.check_env_var = False
                    raise DataMinrException(
                        "{} is not set in the environment please set the environment variable and run the app.".format(
                            key
                        )
                    )
        except DataMinrException as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )

    def get_checkpoint(self):
        """To retrieve last saved checkpoint from checkpointfile.

        Returns:
            None/json: last_data
        """
        try:
            __method_name = inspect.currentframe().f_code.co_name
            self.state = StateManager(
                connection_string=connection_string, file_path="totoken-auth_details"
            )
            last_data = self.state.get()
            if last_data is not None:
                last_data = json.loads(last_data)
            return last_data
        except Exception as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )

    def save_checkpoint(self, data):
        """To save data in checkpoint file.

        Args:
            data (json):Data to be saved in checkpoint file
        """
        try:
            __method_name = inspect.currentframe().f_code.co_name
            if data is None:
                data = {}
                data["auth_response"] = {}
                data["to_token"] = ""
            elif "to_token" not in data:
                data["to_token"] = ""
            self.state.post(json.dumps(data))
        except Exception as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )

    def convert_epoch_to_datetime(self, epoch):
        """To convert epoch timestamp(in seconds) to datatime(in UTC).

        Args:
            epoch (int): epoch timestamp value in seconds

        Returns:
            datetime: converted datetime value in UTC.
        """
        __method_name = inspect.currentframe().f_code.co_name
        applogger.debug(
            "{}(method={}) Converting epoch timestamp to datetime(in UTC).".format(
                self.logs_start_with, __method_name
            )
        )
        return datetime.utcfromtimestamp(epoch).strftime(self.datetime_format)

    def make_rest_call(self, endpoint, params=None, body=None):
        """To call DataMinrPulse API.

        Args:
            endpoint (str): endpoint to call.
            params (json, optional): query parameters to pass in API call. Defaults to None.
            body (json, optional): Request body to pass in API call. Defaults to None.

        Returns:
            json: returns json response if API call succeed.
        """
        try:
            __method_name = inspect.currentframe().f_code.co_name
            applogger.debug(
                "{}(method={}) Calling DataMinrPulse API for endpoint={}".format(
                    self.logs_start_with, __method_name, endpoint
                )
            )
            dataminr_api_url = "{}{}".format(self.base_url, endpoint)
            json_response = {}
            success_flag = False
            response = requests.get(
                url=dataminr_api_url, headers=self.headers, params=params, data=body
            )
            if response.status_code == 400:
                applogger.error(
                    "{}(method={}) The format of the request is incorrect. {}(StatusCode={})".format(
                        self.logs_start_with,
                        __method_name,
                        response.text,
                        response.status_code,
                    )
                )
            elif response.status_code == 401:
                applogger.error(
                    "{}(method={}) Invalid dma token. {}(StatusCode={})".format(
                        self.logs_start_with,
                        __method_name,
                        response.text,
                        response.status_code,
                    )
                )
                self.authentication()
            elif response.status_code == 404:
                applogger.error(
                    "{}(method={}) URL not found. {}(StatusCode={})".format(
                        self.logs_start_with,
                        __method_name,
                        response.text,
                        response.status_code,
                    )
                )
            elif response.status_code == 429:
                applogger.error(
                    "{}(method={}) The rate limit has been exceeded. {}(StatusCode={})".format(
                        self.logs_start_with,
                        __method_name,
                        response.text,
                        response.status_code,
                    )
                )
            elif response.status_code == 500:
                applogger.error(
                    "{}(method={}) The Dataminr server experienced an error. {}(StatusCode={})".format(
                        self.logs_start_with,
                        __method_name,
                        response.text,
                        response.status_code,
                    )
                )
            elif response.status_code == 200:
                json_response = response.json()
                success_flag = True
            else:
                applogger.error(
                    "{}(method={}) Error while calling DataMinr API: StatusCode={} , Message={}".format(
                        self.logs_start_with,
                        __method_name,
                        response.status_code,
                        response.text,
                    )
                )
        except requests.ConnectionError as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )
        except requests.HTTPError as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )
        except requests.RequestException as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )
        except Exception as err:
            applogger.error(
                "{}(method={}) Exception{}".format(
                    self.logs_start_with, __method_name, err
                )
            )
        return json_response, success_flag

    def authentication(self, max_retries=3):
        """To authenticate with DataMinr.

        Args:
            max_retries (int, optional): _description_. Defaults to 3.
        """
        try:
            __method_name = inspect.currentframe().f_code.co_name
            retry_count = 0
            body = {
                "grant_type": "api_key",
                "client_id": self.client_id,
                "client_secret": self.client_secret,
            }
            current_time = datetime.utcnow().strftime(self.datetime_format)
            if self.refresh_token and current_time <= self.token_expiry_time:
                body["refresh_token"] = self.refresh_token
                applogger.debug(
                    "{}(method={}) Generating auth token using refresh token.".format(
                        self.logs_start_with, __method_name
                    )
                )
            success_flag = False
            while retry_count < max_retries:
                status_code, success_flag = self.generate_auth_token(
                    self.auth_url, body
                )
                if status_code == 401:
                    body.pop("refresh_token", None)
                if not success_flag:
                    retry_count += 1
                else:
                    break
        except KeyError as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )
        except Exception as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )

    def generate_auth_token(self, auth_url, body):
        """To generate/regenerate auth token to authenticate with DataMinr API.

        Args:
            auth_url (str): API url to get auth token
            body (_type_): request body to pass in API call.

        Raises:
            DataMinrException: raise exception if fails
        Returns:
            bool: True if succeeds.
        """
        try:
            __method_name = inspect.currentframe().f_code.co_name
            applogger.debug(
                "{}(method={}) Generating Auth token.".format(
                    self.logs_start_with, __method_name
                )
            )
            response = requests.post(url=auth_url, data=body, headers=self.auth_headers)
            success_flag = False
            if response.status_code == 200:
                json_response = response.json()
                self.checkpoint_data["auth_response"] = json_response
                self.save_checkpoint(self.checkpoint_data)
                self.headers.update(
                    {"Authorization": "Dmauth {}".format(json_response["dmaToken"])}
                )
                self.refresh_token = json_response["refreshToken"]
                self.token_expiry_time = self.convert_epoch_to_datetime(
                    json_response["expire"] / 1000
                )
                applogger.info(
                    "{}(method={}) Successfully generated auth token for DataMinrPulse API.".format(
                        self.logs_start_with, __method_name
                    )
                )
                success_flag = True
            elif response.status_code == 401:
                error_message = response.json()["errors"][0]["message"]
                if "refresh token" in error_message:
                    success_flag = False
                elif "client Id" in error_message or "client secret" in error_message:
                    applogger.error(
                        "{}(method={}) Invalid client_id or client_secret. Please enter valid credentials.".format(
                            self.logs_start_with, __method_name
                        )
                    )
                    success_flag = True
                    raise DataMinrException("Please Enter valid client credentials.")
            else:
                applogger.error(
                    "{}(method={}) Error while genrating access token. Status Code: {}, Error: {}".format(
                        self.logs_start_with,
                        __method_name,
                        response.status_code,
                        response.text,
                    )
                )
        except requests.ConnectionError as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )
        except requests.HTTPError as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )
        except requests.RequestException as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )
        except KeyError as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )
        except Exception as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )

        return response.status_code, success_flag

    def validate_auth_token(self, auth_data):
        """To validate existing auth token.

        Args:
            auth_data (dict): _description_
        """
        __method_name = inspect.currentframe().f_code.co_name
        applogger.debug(
            "{}(method={}) Validating auth token.".format(
                self.logs_start_with, __method_name
            )
        )
        if (
            "dmaToken" in auth_data
            and "expire" in auth_data
            and "refreshToken" in auth_data
        ):
            self.headers.update(
                {"Authorization": "Dmauth {}".format(auth_data["dmaToken"])}
            )
            applogger.debug(
                "{} Authorizatin header: {}".format(self.logs_start_with, self.headers)
            )
            self.token_expiry_time = self.convert_epoch_to_datetime(
                auth_data["expire"] / 1000
            )
            self.refresh_token = auth_data.get("refreshToken")
        current_time = datetime.utcnow().strftime(self.datetime_format)
        if current_time >= self.token_expiry_time:
            applogger.info(
                "{}(method={}) Token is expired so generating new auth token.".format(
                    self.logs_start_with, __method_name
                )
            )
            self.authentication()

    def get_lists(self, names, max_retries=3):
        """To fetch lists from DataMinr API.

        Args:
            names (list): names of lists
            max_retries (int, optional): _description_. Defaults to 3.

        Returns:
            list: list of lists object whose value matches with anmes parameters
        """
        try:
            __method_name = inspect.currentframe().f_code.co_name
            applogger.debug(
                "{}(method={}) Getting lists from DataMinr API.".format(
                    self.logs_start_with, __method_name
                )
            )
            retry_count = 0
            while retry_count <= max_retries:
                lists_resp, success_flag = self.make_rest_call(self.get_lists_path)
                if not success_flag:
                    retry_count += 1
                else:
                    lists_resp = lists_resp["watchlists"].values()
                    lists = sum(lists_resp, [])
                    break
        except KeyError as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )
        except Exception as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )
        if not names:
            applogger.info(
                "{}(method={}) Considering all watchlists obtained via DataMinrPulse REST API.".format(
                    self.logs_start_with, __method_name
                )
            )
            return lists
        return [lst for lst in lists if lst["name"] in names]

    def get_lists_names(self):
        """Get lists names.

        Returns:
            _type_: _description_
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            if lists_names:
                return [name.strip() for name in lists_names.split(",")]
            applogger.info(
                "{}(method={}) Lists Names are not provided".format(
                    self.logs_start_with, __method_name
                )
            )
            return None
        except Exception as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )

    def get_list_ids(self, lists):
        """Get list ids.

        Args:
            lists (_type_): _description_
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            self.lists_ids = [lst["id"] for lst in lists]
        except KeyError as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )
        except Exception as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )

    def get_alerts(self, from_token=None):
        """To fetch alerts from DataMinr API.

        Args:
            from_token (_type_, optional): _description_. Defaults to None.

        Yields:
            _type_: _description_
        """
        try:
            __method_name = inspect.currentframe().f_code.co_name
            applogger.debug(
                "{}(method={}) Getting Alerts.".format(
                    self.logs_start_with, __method_name
                )
            )
            if not self.lists_ids:
                self.lists_ids = [
                    lst["id"] for lst in self.get_lists(names=self.get_lists_names())
                ]
            alerts_page = self._get_alerts_page(self.lists_ids, from_token=from_token)
            while alerts_page["alerts"]:
                pagination_token = alerts_page["to"]
                for alert in alerts_page["alerts"]:
                    if alert.get("alertType") and alert_type not in (
                        "all",
                        alert["alertType"]["id"],
                    ):
                        continue
                    yield alert, pagination_token
                alerts_page = self._get_alerts_page(
                    self.lists_ids, from_token=pagination_token
                )
        except KeyError as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )
        except Exception as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )

    def _get_alerts_page(self, lists_ids, from_token=None, max_retries=3):
        """To fetch alerts for a page.

        Args:
            lists_ids (_type_): _description_
            from_token (_type_, optional): _description_. Defaults to None.
            max_retries (int, optional): _description_. Defaults to 3.

        Returns:
            _type_: _description_
        """
        try:
            __method_name = inspect.currentframe().f_code.co_name
            applogger.debug(
                "{}(method={}) Getting alerts page for lists {}.".format(
                    self.logs_start_with, __method_name, lists_ids
                )
            )
            params = {
                "alertversion": ALERT_VERSION,
                "lists": ",".join(map(str, lists_ids)),
            }
            if from_token:
                params["from"] = from_token
            retry_count = 0
            while retry_count < max_retries:
                alerts, success_flag = self.make_rest_call(
                    self.get_alerts_path, params=params
                )
                if not success_flag:
                    retry_count += 1
                else:
                    return alerts["data"]
            applogger.error(
                "{}(method={}) Max retries exceeded for fetching DataMiner Alerts.".format(
                    self.logs_start_with, __method_name
                )
            )
        except Exception as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )

    def get_related_alerts(self, alert_id, include_root=False, max_retries=3):
        """To fetch related alerts for given alertid.

        Args:
            alert_id (_type_): _description_
            include_root (bool, optional): _description_. Defaults to False.
            max_retries (int, optional): _description_. Defaults to 3.

        Returns:
            _type_: _description_
        """
        try:
            __method_name = inspect.currentframe().f_code.co_name
            applogger.debug(
                "{}(method={}) Getting alerts related to {}".format(
                    self.logs_start_with, __method_name, alert_id
                )
            )
            params = {
                "alertversion": ALERT_VERSION,
                "id": alert_id,
                "includeRoot": include_root,
            }
            retry_count = 0
            while retry_count < max_retries:
                related_alerts, success_flag = self.make_rest_call(
                    self.get_related_alerts_path, params
                )
                if not success_flag:
                    retry_count += 1
                else:
                    return related_alerts
        except Exception as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )

    def get_alerts_data(self, checkpoint=None):
        """To get alerts and related alerts.

        Args:
            checkpoint (_type_, optional): _description_. Defaults to None.

        Yields:
            _type_: _description_
        """
        try:
            __method_name = inspect.currentframe().f_code.co_name
            applogger.debug(
                "{}(method={}) Getting alerts data starting from {}.".format(
                    self.logs_start_with, __method_name, checkpoint
                )
            )
            lists = self.get_lists(names=self.get_lists_names())
            self.lists_ids = [lst["id"] for lst in lists]

            alerts = self.get_alerts(from_token=checkpoint)

            for alert, alert_checkpoint in alerts:
                if related_alerts and alert["availableRelatedAlerts"] > 0:
                    related_alerts_resp = self.get_related_alerts(alert["alertId"])
                    for related_alert in related_alerts_resp:
                        yield related_alert, alert_checkpoint

                    alert["relatedAlerts"] = [
                        related["alertId"] for related in related_alerts_resp
                    ]

                yield alert, alert_checkpoint
        except KeyError as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )
        except Exception as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )

    def prepare_alerts_events(self, alert):
        """Prepare alert data to send in sentinel.

        Args:
            alert (_type_): _description_

        Returns:
            _type_: _description_
        """
        try:
            __method_name = inspect.currentframe().f_code.co_name
            alert_location = alert.get("eventLocation", {})
            alert_location_name = alert_location.get("name")
            if alert_location_name:
                alert["eventLocation"]["country"] = alert_location_name.split(", ")[-1]

            source = self.get_source(alert)
            if source:
                alert["eventSource"] = source
        except KeyError as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )
        except Exception as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )
        return alert

    def get_source(self, data):
        """Extract source for alert from caption.

        Args:
            data (_type_): _description_

        Returns:
            _type_: _description_
        """
        try:
            __method_name = inspect.currentframe().f_code.co_name
            caption = data["caption"]
            if SOURCE_SEPARATOR not in caption.lower():
                return None
            return caption[
                caption.lower().index(SOURCE_SEPARATOR) + len(SOURCE_SEPARATOR): -1
            ]
        except KeyError as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )
        except Exception as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )

    def send_dataminer_alerts_to_sentinel(self):
        """To fetch alerts and sen to sentinel."""
        try:
            __method_name = inspect.currentframe().f_code.co_name
            self.check_environment_var_exist()
            checkpoint = self.get_checkpoint()
            if checkpoint is not None:
                if checkpoint.get("auth_response"):
                    self.validate_auth_token(checkpoint.get("auth_response"))
                new_checkpoint = checkpoint.get("to_token")
            else:
                self.authentication()
                new_checkpoint = None
            alerts_response = self.get_alerts_data(new_checkpoint)
            applogger.info(
                "{}(method={}) Fetching alerts data from DataMinrPulse and sending it to sentinel.".format(
                    self.logs_start_with, __method_name
                )
            )
            azuresentinel = AzureSentinel()
            for alert, new_checkpoint in alerts_response:
                alert_body = self.prepare_alerts_events(alert)
                self.alert_body.append(alert_body)
                self.alert_count += 1
                if len(self.alert_body) == 100:
                    status_code = azuresentinel.post_data(
                        body=json.dumps(self.alert_body), log_type=alerts_table
                    )
                    if status_code == 200:
                        applogger.info(
                            "{}(method={}) Posted {} alert data successfully.".format(
                                self.logs_start_with, __method_name, self.alert_count
                            )
                        )
                        self.checkpoint_data["to_token"] = new_checkpoint
                        self.save_checkpoint(self.checkpoint_data)
                        applogger.debug(
                            "{}(method={}) Saved checkpoint token and auth response:{}".format(
                                self.logs_start_with,
                                __method_name,
                                self.checkpoint_data,
                            )
                        )
                        self.alert_body = []
                        self.alert_count = 0
            if self.alert_body:
                json.dumps(self.alert_body)
                status_code = azuresentinel.post_data(
                    body=json.dumps(self.alert_body), log_type=alerts_table
                )
                if status_code == 200:
                    applogger.info(
                        "{}(method={}) Posted {} alert data successfully.".format(
                            self.logs_start_with, __method_name, self.alert_count
                        )
                    )
                    self.checkpoint_data["to_token"] = new_checkpoint
                    self.save_checkpoint(self.checkpoint_data)
                    applogger.debug(
                        "{}(method={}) Saved checkpoint token and auth response:{}".format(
                            self.logs_start_with, __method_name, self.checkpoint_data
                        )
                    )
        except DataMinrException as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )
        except Exception as err:
            applogger.error(
                self.error_log.format(self.logs_start_with, __method_name, err)
            )
