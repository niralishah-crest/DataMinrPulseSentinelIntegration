import os
import json
import inspect
import requests
from .consts import LOGS_STARTS_WITH, ENDPOINTS, BASE_URL
from .dataminrpulse_exception import DataminrPulseException
from .logger import applogger


class DataminrPulseConfigureSettings:
    """This class will add integation settings in DataminrPulse to receive data via RTAPin Sentinel."""
    def __init__(self) -> None:
        self.base_url = BASE_URL
        self.auth_endpoint = ENDPOINTS["authentication"]
        self.get_lists_path = ENDPOINTS.get("get_lists")
        self.add_settings_path = ENDPOINTS.get("add_integration_settings")
        self.logs_starts_with = LOGS_STARTS_WITH
        self.error_logs = "{}(method={}) {}"
        self.client_id = "",
        self.client_secret = ""
        self.auth_headers = {"Content-Type": "application/x-www-form-urlencoded"}
        self.headers = {}
        self.lists_ids = []

    def make_rest_call(self, endpoint, request_method, params=None, body=None):
        """To call DataminrPulse API.

        Args:
            endpoint (str): endpoint to call.
            request_method: method to use for requesting an endpoint.(POST/GET)
            params (json, optional): query parameters to pass in API call. Defaults to None.
            body (json, optional): Request body to pass in API call. Defaults to None.

        Returns:
            json: returns json response if API call succeed.
        """
        try:
            __method_name = inspect.currentframe().f_code.co_name
            applogger.debug(
                "{}(method={}) Calling DataMinrPulse API for endpoint={}".format(
                    self.logs_starts_with, __method_name, endpoint
                )
            )
            dataminr_api_url = "{}{}".format(self.base_url, endpoint)
            response = requests.request(
                method=request_method, url=dataminr_api_url, headers=self.headers, params=params, data=body
            )
            if response.status_code == 400:
                applogger.error(
                    "{}(method={}) The format of the request is incorrect. {}(StatusCode={})".format(
                        self.logs_starts_with,
                        __method_name,
                        response.text,
                        response.status_code,
                    )
                )
            elif response.status_code == 401:
                applogger.error(
                    "{}(method={}) Invalid dma token. {}(StatusCode={})".format(
                        self.logs_starts_with,
                        __method_name,
                        response.text,
                        response.status_code,
                    )
                )
            elif response.status_code == 403:
                applogger.error(
                    "{}(method={}) Not permitted to access this resource/delivery setting/watchlist. {}(StatusCode={})".format(
                        self.logs_starts_with,
                        __method_name,
                        response.text,
                        response.status_code,
                    )
                )
            elif response.status_code == 500:
                applogger.error(
                    "{}(method={}) The Dataminr server experienced an error. {}(StatusCode={})".format(
                        self.logs_starts_with,
                        __method_name,
                        response.text,
                        response.status_code,
                    )
                )
            elif response.status_code == 200:
                applogger.debug("{}(method={}) request to endpoint {} is completed successfully.".format(self.logs_starts_with, __method_name, endpoint))
            else:
                applogger.error(
                    "{}(method={}) Error while calling DataMinr API: StatusCode={} , Message={}".format(
                        self.logs_starts_with,
                        __method_name,
                        response.status_code,
                        response.text,
                    )
                )
        except requests.ConnectionError as err:
            applogger.error(
                self.error_logs.format(self.logs_starts_with, __method_name, err)
            )
            raise DataminrPulseException(err)
        except requests.HTTPError as err:
            applogger.error(
                self.error_logs.format(self.logs_starts_with, __method_name, err)
            )
            raise DataminrPulseException(err)
        except requests.RequestException as err:
            applogger.error(
                self.error_logs.format(self.logs_starts_with, __method_name, err)
            )
            raise DataminrPulseException(err)
        except Exception as err:
            applogger.error(
                "{}(method={}) Exception{}".format(
                    self.logs_starts_with, __method_name, err
                )
            )
            raise DataminrPulseException(err)
        return response

    def authentication(self):
        try:
            __method_name = inspect.currentframe().f_code.co_name
            body = {
                "grant_type": "api_key",
                "client_id": self.client_id,
                "client_secret": self.client_secret,
            }
            auth_response = self.make_rest_call(self.auth_endpoint, "POST", body=body)
            if auth_response.status_code == 200:
                json_auth_response = auth_response.json()
                access_token = json_auth_response.get("dmaToken")
                self.headers.update(
                    {"Authorization": "Dmauth {}".format(access_token)}
                )
            else:
                applogger.error("{}(method={}) Error while authenticatin with DataminrPulse account. StatusCode={} Message={}".format(self.logs_starts_with, __method_name, auth_response.status_code, auth_response.text))
                raise DataminrPulseException(auth_response.text)
        except DataminrPulseException as err:
            raise DataminrPulseException(err)
        except Exception as err:
            applogger.error(
                "{}".format(
                    self.error_logs.format(self.logs_starts_with, __method_name, err)
                )
            )
            raise DataminrPulseException(err)

    def get_lists(self):
        """To fetch lists from DataMinr API.

        Args:
            names (list): names of lists
            max_retries (int, optional): _description_. Defaults to 3.

        Returns:
            list: list of lists object whose value matches with anmes parameters
        """
        try:
            __method_name = inspect.currentframe().f_code.co_name
            applogger.debug(
                "{}(method={}) Getting lists from DataMinr API.".format(
                    self.logs_starts_with, __method_name
                )
            )
            api_response = self.make_rest_call(self.get_lists_path, "GET")
            if api_response.status_code == 200:
                json_api_response = api_response.json()
                lists_resp = json_api_response.get("watchlists").values()
                lists = sum(lists_resp, [])
            else:
                applogger.error("{}(method={}) Error while fetching lists configured in provided Dataminr account. StatusCode={} Message={}".format(self.logs_starts_with, __method_name, api_response.status_code, api_response.text))
                raise DataminrPulseException(api_response.text)
        except KeyError as err:
            applogger.error(
                self.error_logs.format(self.logs_starts_with, __method_name, err)
            )
        except Exception as err:
            applogger.error(
                self.error_logs.format(self.logs_starts_with, __method_name, err)
            )
        return lists

    def get_list_ids(self, lists):
        """Get list ids.

        Args:
            lists (_type_): _description_
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            self.lists_ids = [lst["id"] for lst in lists]
        except KeyError as err:
            applogger.error(
                self.error_log.format(self.logs_starts_with, __method_name, err)
            )
        except Exception as err:
            applogger.error(
                self.error_log.format(self.logs_starts_with, __method_name, err)
            )

    def prepare_integration_settings_body(self, data):
        body = {
            "watchlists": [
            ],
            "deliveryType": "Sentinel",
            "deliveryInfo": {
                "webhook": "",
                "authToken": ""
            }
        }
        watchlists = []
        for id in self.lists_ids:
            watchlists.append({"id": id,
            "brands": [
                "ALERT", "FLASH", "URGENT"
            ]})
        body.update({"watchlists"})
        body.update({"webhook": data.get("url")})
        body.update({"authToken": data.get("token")})
        return body

    def add_integration_settings(self, data):
        __method_name = inspect.currentframe().f_code.co_name
        body = self.prepare_integration_settings_body(data)
        json_api_response = {}
        api_response = self.make_rest_call(self.add_settings_path, "POST", body=body)
        if api_response.status_code == 200:
            json_api_response = api_response.json()
        else:
            applogger.error("{}(method={}) Error while adding integration settings in DataminrPulse account. StatusCode={} Message={}".format(self.logs_starts_with, __method_name, api_response.status_code, api_response.text))
            raise DataminrPulseException(api_response.text)
        return json_api_response

    def add_webhook_configuration_to_dataminr(self, data, client_id, client_secret):
        __method_name = inspect.currentframe().f_code.co_name
        success_flag = False
        setting_id = None
        self.client_id = client_id,
        self.client_secret = client_secret
        self.authentication()
        lists = self.get_lists()
        if lists:
            self.get_list_ids(lists)
        else:
            applogger.warning("{}(method={}) At least one watchlist must be configured on Dataminr acoount to get alerts for provided webhook url.".format(self.logs_starts_with, __method_name))
            raise DataminrPulseException("Please configure atleast one watchlist on your Dataminr account.")
        json_response = self.add_integration_settings(data)
        if json_response:
            applogger.info("Integration settings are added successfully to Dataminr account.")
            applogger.debug("Integration settings are added successfully to Dataminr account with settingId={}".format(json_response.get("deliverySettingId")))
            setting_id = json_response.get("deliverySettingId")
            success_flag = True
        return success_flag, setting_id
