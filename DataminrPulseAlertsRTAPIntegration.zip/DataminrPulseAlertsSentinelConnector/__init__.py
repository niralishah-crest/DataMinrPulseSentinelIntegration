"""This __init__ file will be called once data is generated in webhook and it creates trigger."""
import time

from DataminrPulseAlertsSentinelConnector.dataminrpulse_exception import DataminrPulseException
from .consts import LOGS_STARTS_WITH
from .logger import applogger
from .dataminr_pulse import DataminrPulse
import azure.functions as func


def main(request: func.HttpRequest) -> func.HttpResponse:
    """
    Start the execution.

    Args:
        request (func.HttpRequest): To get data from request body pushed by webhook

    Returns:
        func.HttpResponse: Status of Http request process (successful/failed).
    """
    applogger.info("{} Start processing".format(LOGS_STARTS_WITH))
    try:
        start = time.time()
        dataminrpulse_obj = DataminrPulse()
        dataminrpulse_obj.send_alert_data_to_sentinel(request)
        end = time.time()
        applogger.info(
            "{} :time taken for data ingestion is {} sec".format(
                LOGS_STARTS_WITH, int(end - start)
            )
        )
    except DataminrPulseException as err:
        return func.HttpResponse(err)
    else:
        return func.HttpResponse("Data ingetsed successfully to Sentinel log analytics workspace.")
    finally:
        applogger.info("{} execution completed.".format(LOGS_STARTS_WITH))
