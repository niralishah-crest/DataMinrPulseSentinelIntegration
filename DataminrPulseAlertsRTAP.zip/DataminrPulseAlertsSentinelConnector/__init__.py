"""This __init__ file will be called once data is generated in webhook and it creates trigger."""
import time

from .dataminrpulse_exception import DataminrPulseException
from .consts import LOGS_STARTS_WITH
from .logger import applogger
from .dataminr_pulse import DataminrPulse
import azure.functions as func


def main(request: func.HttpRequest) -> func.HttpResponse:
    """
    Start the execution.

    Args:
        request (func.HttpRequest): To get data from request body pushed by webhook

    Returns:
        func.HttpResponse: Status of Http request process (successful/failed).
    """
    applogger.info("{} Start processing".format(LOGS_STARTS_WITH))
    try:
        start = time.time()
        dataminrpulse_obj = DataminrPulse()
        setting_id = dataminrpulse_obj.send_alert_data_to_sentinel(request)
        if setting_id is not None:
            return func.HttpResponse(
                "Integration settings are added successfully to Dataminr account with settingId={}".format(
                    setting_id
                )
            )
        else:
            end = time.time()
            applogger.info(
                "{} :time taken for data ingestion is {} sec".format(
                    LOGS_STARTS_WITH, int(end - start)
                )
            )
            return func.HttpResponse(
                "Data ingetsed successfully to Sentinel log analytics workspace."
            )
    except DataminrPulseException as err:
        return func.HttpResponse(
            "Error: {}".format(
                err
            )
        )
    finally:
        applogger.info("{} execution completed.".format(LOGS_STARTS_WITH))
