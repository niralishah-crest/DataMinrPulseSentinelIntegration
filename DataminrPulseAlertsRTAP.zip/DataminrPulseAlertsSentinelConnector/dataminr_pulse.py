"""This file contains implementation to ingest Dataminr RTAP alert data into sentinel."""
import os
import json
import inspect
from .sentinel import MicrosoftSentinel
from .consts import LOGS_STARTS_WITH, RELATEDALERTS_TABLE_NAME
from .dataminrpulse_exception import DataminrPulseException
from .logger import applogger
from .dataminrpulse_integration_settings import DataminrPulseConfigureSettings

alerts_table = os.environ.get("AlertsTableName")
client_id = os.environ.get("ClientId")
client_secret = os.environ.get("ClientSecret")
related_alerts_table = RELATEDALERTS_TABLE_NAME.format(alerts_table)


class DataminrPulse:
    """This class contains methods to get data from request body pushed via Dataminr RTAP and ingest into Sentinel."""

    def __init__(self) -> None:
        """Initialize instance variables for class."""
        self.logs_starts_with = LOGS_STARTS_WITH
        self.data = {}
        self.microsoftsentinel = MicrosoftSentinel()
        self.error_logs = "{}(method={}) {}"
        self.check_environment_var_existance()

    def check_environment_var_existance(self):
        """To verify that all required environment variables are exist.

        Raises:
            DataminrPulseException: raise exception if any of the required environment variable is not set.
        """
        __method_name = inspect.currentframe().f_code.co_name
        env_var = [
            {"ClientId": client_id},
            {"ClientSecret": client_secret},
            {"AlertsTableName": alerts_table},
        ]
        try:
            applogger.debug(
                "{}(method={}) Checking environment variables are exist or not.".format(
                    self.logs_starts_with, __method_name
                )
            )
            for i in env_var:
                key, val = next(iter(i.items()))
                if val is None:
                    raise DataminrPulseException(
                        "{}(method={}) {} is not set in the environment please set the environment variable.".format(
                            self.logs_starts_with, __method_name, key
                        )
                    )
            applogger.debug(
                "{}(method={}) All custom environment variable exists.".format(
                    self.logs_starts_with, __method_name
                )
            )
        except DataminrPulseException as err:
            applogger.error(err)
            raise DataminrPulseException(err)
        except Exception as err:
            applogger.error(
                "{}".format(
                    self.error_logs.format(self.logs_starts_with, __method_name, err)
                )
            )
            raise DataminrPulseException(err)

    def add_integration_settings_to_dataminr(self):
        """To configure integration settings for Dataminr.

        Raises:
            DataminrPulseException: raises when any error occurs.
        Returns:
            _type_: _description_
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            configuresettings = DataminrPulseConfigureSettings()
            settings_id = configuresettings.add_webhook_configuration_to_dataminr(
                self.data, client_id, client_secret
            )
            return settings_id
        except DataminrPulseException as err:
            raise DataminrPulseException(
                "Error while adding integration settings to Dataminr account. {}".format(
                    err
                )
            )
        except Exception as err:
            applogger.error(
                "{}".format(
                    self.error_logs.format(self.logs_starts_with, __method_name, err)
                )
            )
            raise DataminrPulseException(
                "Error while adding integration settings to Dataminr account. {}".format(
                    err
                )
            )

    def get_data_from_request_body(self, request):
        """Get data from request body.

        Args:
            request (func.HttpRequest): Azure function HttpRequest class object

        Raises:
            DataminrPulseException: raises when an error occurs.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            self.data = request.get_json()
        except ValueError as value_error:
            applogger.error(
                "{}".format(
                    self.error_logs.format(
                        self.logs_starts_with, __method_name, value_error
                    )
                )
            )
            raise DataminrPulseException(value_error)
        except Exception as err:
            applogger.error(
                "{}".format(
                    self.error_logs.format(self.logs_starts_with, __method_name, err)
                )
            )
            raise DataminrPulseException(err)

    def prepare_rawtoredirecturl(self, alerts_data):
        """
        Prepare a data for subfield rawToRedirectedUrls in alert_data.

        Args:
            alerts_data (json): alert obtained from
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            redirect_urls = alerts_data["internalOnly"]["redirectLinks"][
                "rawToRedirectedUrls"
            ]
            alerts_data["internalOnly"]["redirectLinks"]["rawToRedirectedUrls"] = [
                redirect_urls
            ]
        except KeyError as err:
            applogger.error(
                "{}".format(
                    self.error_logs.format(
                        self.logs_starts_with, __method_name, err
                    )
                )
            )
            raise DataminrPulseException(err)
        except Exception as err:
            applogger.error(
                "{}".format(
                    self.error_logs.format(self.logs_starts_with, __method_name, err)
                )
            )
            raise DataminrPulseException(err)

    def post_related_alerts(self, related_alerts, alert_id):
        """Post related alerts in seperate table obtained in alerts data received via DataminrPulse RTAP.

        Args:
            related_alerts (_type_): alerts related to provided alert_id
            alert_id (_type_): id  of an alert whose related alerts are going to be ingested.

        Raises:
            DataminrPulseException: raises when any error occurs.

        Returns:
            _type_: _description_
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            count = 0
            related_alert_ids = []
            applogger.info("{}(method={}) Received total {} alerts data related to id={} via RTAP.".format(
                    self.logs_starts_with,
                    __method_name,
                    len(related_alerts),
                    alert_id,
                ))
            for alert in related_alerts:
                alert.update({"alert_relatedTo": alert_id})
                self.prepare_rawtoredirecturl(alert)
                related_alert_ids.append(alert.get("index"))
                body = json.dumps(alert)
                self.microsoftsentinel.post_data(body, related_alerts_table)
                count += 1
            applogger.info(
                "{}(method={}) Posted total {} alerts data related to id={} successfully.".format(
                    self.logs_starts_with,
                    __method_name,
                    count,
                    alert_id,
                )
            )
            return related_alert_ids
        except DataminrPulseException as err:
            raise DataminrPulseException(err)
        except Exception as err:
            applogger.error(
                "{}".format(
                    self.error_logs.format(self.logs_starts_with, __method_name, err)
                )
            )
            raise DataminrPulseException(err)

    def prepare_alerts(self, alert_data):
        """Prepare alerts data for ingesting in Sentinel.

        Args:
            alert_data (json): Alert data received via Dataminr RTAP.

        Raises:
            DataminrPulseException: raises when any error occurs.

        Returns:
            alert_data(json): returns prepared alert data
        """
        __method_name = inspect.currentframe().f_code.co_name

        try:
            self.prepare_rawtoredirecturl(alert_data)
            if alert_data.get("relatedAlerts"):
                related_alerts = self.post_related_alerts(
                    alert_data.get("relatedAlerts"), alert_data.get("index")
                )
                alert_data.update({"relatedAlerts": related_alerts})
            return alert_data
        except DataminrPulseException as err:
            raise DataminrPulseException(err)
        except Exception as error:
            applogger.error(
                "{}".format(
                    self.error_logs.format(self.logs_starts_with, __method_name, error)
                )
            )
            raise DataminrPulseException(error)

    def send_alert_data_to_sentinel(self, request):
        """To get alerts data from request body received via DataminrPulse RTAP and ingest into Sentinel.

        Args:
            request (_type_): _description_

        Raises:
            DataminrPulseException: raises when any error occurs.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            self.get_data_from_request_body(request)
            settings_id = None
            if self.data:
                if type(self.data) == dict:
                    if self.data.get("integration-settings"):
                        settings_id = self.add_integration_settings_to_dataminr()
                    else:
                        self.data = self.prepare_alerts(self.data)
                        body = json.dumps(self.data)
                        applogger.debug(
                            "{}(method={}) Posting the RTAP alerts from DataminrPulseAlertsSentinelConnector".format(
                                self.logs_starts_with, __method_name
                            )
                        )
                        self.microsoftsentinel.post_data(
                            body,
                            alerts_table,
                        )
                        applogger.info(
                            "{}(method={}) Alert data is ingested into Sentinel.".format(
                                self.logs_starts_with, __method_name
                            )
                        )
                else:
                    applogger.info("{}(method={}) Total alerts recived via RTAP are {}.".format(
                        self.logs_starts_with, __method_name, len(self.data)
                        )
                    )
                    count = 0
                    for alert in self.data:
                        alert = self.prepare_alerts(alert)
                        count += 1
                    body = json.dumps(self.data)
                    applogger.debug(
                        "{}(method={}) Posting the RTAP alert data from DataminrPulseAlertsSentinelConnector".format(
                            self.logs_starts_with, __method_name
                        )
                    )
                    self.microsoftsentinel.post_data(
                        body,
                        alerts_table,
                    )
                    applogger.info("{}(method={}) Total {} alerts ingested in Sentinel.".format(
                        self.logs_starts_with, __method_name, count
                        )
                    )
                return settings_id
            else:
                applogger.info(
                    "{}(method={})No required data found.".format(
                        self.logs_starts_with, __method_name
                    )
                )
                raise DataminrPulseException("No required data found for this trigger.")
        except DataminrPulseException as err:
            raise DataminrPulseException(err)
        except Exception as error:
            applogger.error(
                "{}".format(
                    self.error_logs.format(self.logs_starts_with, __method_name, error)
                )
            )
            raise DataminrPulseException(error)
